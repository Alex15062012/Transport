from django.contrib import admin
from .models import Transaction, SubscriptionTariff


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'amount', 'status', 'date', ]


class SubscriptionTariffAdmin(admin.ModelAdmin):
    list_display = ['price', 'duration']

    

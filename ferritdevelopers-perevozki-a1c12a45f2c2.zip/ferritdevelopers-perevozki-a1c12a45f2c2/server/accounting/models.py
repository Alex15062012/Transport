from django.db import models
from accounts.models import User
from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.timezone import now
import hashlib
import requests
from pinax.notifications.models import send

PENDING = 0
COMPLETE = 1
MODERATING = -1
PROCESSING = -2
REJECTED = -3

TRANSACTION_STATUS_CHOICES = (
    (PENDING, _('В процессе')),
    (PROCESSING, _('Обрабатывается')),
    (COMPLETE, _('Завершена')),
    (MODERATING, _("На рассмотрении")),
    (REJECTED, _("Отклонено")),
)


class Transaction(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True)
    status = models.IntegerField(choices=TRANSACTION_STATUS_CHOICES, default=PENDING)
    ps_details = models.TextField(blank=True, null=True)
    date = models.DateTimeField(auto_now_add=True)
    reason = models.CharField(max_length=32, blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    is_notified = models.BooleanField(default=False)
    is_checked = models.BooleanField(default=False)
    tariff = models.ForeignKey('SubscriptionTariff', null=True, blank=True)

    def init_payment(self):
        data = {"Amount": str(int(self.amount)*100),
                'CustomerKey': str(self.user.id),
                "Description": self.comment if self.comment is not None else '',
                'FailURL': str(settings.SITE_URL + '/balance/'),
                'NotificationURL': str(settings.SITE_URL + '/balance/notify/'),
                "OrderId": str(self.id),
                "Password": settings.BANK_TERMINAL_PASSWORD,
                'PayType': 'O',
                'SuccessURL':  str(settings.SITE_URL + '/balance/'),
                "TerminalKey": settings.BANK_TERMINAL_ID}
        s = ''
        for x in data:
            s += data[x]
        data['Token'] = hashlib.sha256(s.encode('utf-8')).hexdigest()
        url = 'https://securepay.tinkoff.ru/v2/Init'

        resp = requests.post(url, json=data)
        result = resp.json()
        self.ps_details = resp.text
        self.save()
        try:
            return result['PaymentURL']
        except KeyError:
            return None

    def check_payment(self):
        url = 'https://securepay.tinkoff.ru/v2/CheckOrder'
        data = {
            'TerminalKey': settings.BANK_TERMINAL_ID,
            'OrderId': str(self.id)
        }
        to_hash = data.copy()
        to_hash['Password'] = settings.BANK_TERMINAL_PASSWORD
        s = []
        for k in sorted(to_hash.keys()):
            print(k, to_hash[k])
            s.append(to_hash[k])
        print(s)
        s = ''.join(s)
        data['Token'] = hashlib.sha256(s.encode('utf-8')).hexdigest()

        resp = requests.post(url, json=data)
        result = resp.json()
        print(result)


@receiver(post_save, sender=Transaction)
def notify_owner(sender, **kwargs):
    instance = kwargs.get('instance')
    if instance.status == COMPLETE and not instance.is_notified:
        send([instance.user], "finance_transaction_complete", {"transaction": instance})

        instance.is_notified = True
        instance.save()


class SubscriptionTariff(models.Model):
    price = models.IntegerField()
    duration = models.DurationField()


class Subscription(models.Model):
    tariff = models.ForeignKey(SubscriptionTariff, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=now)
    starts_at = models.DateTimeField(null=True)



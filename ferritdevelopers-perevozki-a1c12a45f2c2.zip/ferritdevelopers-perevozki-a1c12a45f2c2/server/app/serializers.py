from .models import VehicleCategory, VehicleCategoryAttribute, VehicleCategoryAttributeValue
from rest_framework import serializers


class VehicleCategoryAttributeValueSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleCategoryAttributeValue
        fields = ['id', 'attribute_id', 'label', 'value', 'min_value', 'max_value', 'position']


class VehicleCategoryAttributeSerializer(serializers.ModelSerializer):
    values = VehicleCategoryAttributeValueSerializer(many=True, read_only=True)

    class Meta:
        model = VehicleCategoryAttribute
        fields = ['id', 'category_id', 'name', 'search_field_type', 'values']


class VehicleCategorySerializer(serializers.ModelSerializer):
    attributes = VehicleCategoryAttributeSerializer(many=True, read_only=True)

    class Meta:
        model = VehicleCategory
        fields = ['id', 'name', 'parent_id', 'attributes']

from django.apps import AppConfig
from .signals import handlers
from django.db.models.signals import post_migrate


class AccountingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounting'

    def ready(self):
        post_migrate.connect(handlers.create_notice_types, sender=self)

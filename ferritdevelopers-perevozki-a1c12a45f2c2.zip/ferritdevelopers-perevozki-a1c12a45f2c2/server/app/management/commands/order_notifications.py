from django.core.management.base import BaseCommand
from ...models import JobOrder, JobOrderNotification, Vehicle, Truck, ACTIVE
from django.db.models import Count, F, Q
from time import sleep
from django.contrib.gis.geos import Point
from django.contrib.gis.db.models.functions import Distance
from datetime import timedelta
from django.utils.timezone import now
from django.db.models.expressions import RawSQL

class Command(BaseCommand):
    help = "My shiny new management command."

    def handle(self, *args, **options):
        while True:
            qs = JobOrder.objects.annotate(
                num_notifications=Count('notifications'))\
                .filter(num_messages__gt=F('num_notifications'), status=ACTIVE)\
                .filter(Q(notify_until__isnull=True) | Q(notify_until__lt=now()))

            if not qs.exists():
                sleep(1)
                continue
            for o in qs:
                if o.content_type.model == 'cargomoveorder':
                    pnt = o.content_object.points.first()
                    ref_location = Point(pnt.latitude, pnt.longitude, srid=4326)

                    exclude = JobOrderNotification.objects.filter(order=o).values_list('vehicle_id', flat=True)
                    qs = Vehicle.objects.filter(
                        states__locations__starts_at__lte=o.content_object.load_time,
                        states__locations__ends_at__gt=o.content_object.load_time,
                        content_type__model='truck',
                        ).exclude(id__in=exclude).annotate(
                        distance=Distance('states__locations__location', ref_location)
                    ).annotate(
                        load_capacity=RawSQL(
                            'SELECT load_capacity FROM app_truck AS t WHERE t.vehicle_id=app_vehicle.id', ()
                        ),
                        width=RawSQL('SELECT width FROM app_truck AS t WHERE t.vehicle_id=app_vehicle.id', ()),
                        height=RawSQL('SELECT height FROM app_truck AS t WHERE t.vehicle_id=app_vehicle.id', ()),
                        length=RawSQL('SELECT length FROM app_truck AS t WHERE t.vehicle_id=app_vehicle.id', ()),
                        ).filter(
                        load_capacity__gt=o.content_object.weight,
                                 ).distinct().order_by('distance')
                    vehicle = qs.first()
                    if vehicle is None:
                        continue
                    notification = JobOrderNotification.objects.create(
                        vehicle=vehicle, order=o, created_at=now(), recipient=vehicle.owner,
                        valid_until=now()+timedelta(seconds=300)
                                                                       )
                    notification.create_message()




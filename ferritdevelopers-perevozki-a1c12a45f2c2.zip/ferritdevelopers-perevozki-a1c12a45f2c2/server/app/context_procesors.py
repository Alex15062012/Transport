from .models import VehicleCategory, ServiceType
from .serializers import VehicleCategorySerializer
import json


def categories(request):
    qs = VehicleCategory.objects.all()
    ser = VehicleCategorySerializer(qs, many=True, read_only=True)
    ctx = {'service_types': ServiceType.objects.all(), 'vehicle_types': json.dumps(ser.data, ensure_ascii=False)}
    return ctx

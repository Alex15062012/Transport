from django import forms
from .models import JobOrder


class JobOrderAdminForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        valid_ids = []
        for ct in self.fields['content_type'].queryset:
            cls = ct.model_class()
            if getattr(cls, 'valid_for_job_order', False):
                valid_ids.append(ct.id)
        self.fields['content_type'].queryset = self.fields['content_type'].queryset.filter(id__in=valid_ids)

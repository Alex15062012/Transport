from pinax.notifications.backends.base import BaseBackend
from django.utils.translation import ugettext
from django.template.loader import render_to_string
from .utils import queue_sms


class SMSBackend(BaseBackend):
    spam_sensitivity = 2

    def can_send(self, user, notice_type, scoping):
        ret = super().can_send(user, notice_type, scoping)
        if ret and user.phone is not None:
            return True
        return False

    def deliver(self, recipient, sender, notice_type, extra_context):
        context = self.default_context()
        context.update({
            "recipient": recipient,
            "sender": sender,
            "notice": ugettext(notice_type.display),
        })
        context.update(extra_context)

        messages = self.get_formatted_messages((
            "short.txt",
            "full.txt"
        ), notice_type.label, context)
        print(context)
        print(messages)
        context.update({
            "message": messages["short.txt"],
        })

        context.update({
            "message": messages["full.txt"]
        })
        print(context)
        text = render_to_string("pinax/notifications/sms.txt", context)
        # TODO: ensure that we always have valid phone number here
        try:
            queue_sms([recipient], text)
        except Exception as e:
            print(e)



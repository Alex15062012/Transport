"""
Forms and validation code for user registration.

Note that all of these forms assume your user model is similar in
structure to Django's default User class. If your user model is
significantly different, you may need to write your own form class;
see the documentation for notes on custom user models with
django-registration.

"""
import re

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.utils.translation import gettext_lazy as _
from phonenumber_field.formfields import PhoneNumberField
from . import validators
from .models import SMSActivationCode, EmailConfirmation, UserPhoto
from django.db.models import Q
from datetime import timedelta
from django.contrib.auth import authenticate
from phonenumber_field.validators import validate_international_phonenumber
import re
from app.widgets import CropAbleDropZoneImageInput

User = get_user_model()


class RegistrationForm(UserCreationForm):
    """
    Form for registering a new user account.

    Validates that the requested username is not already in use, and
    requires the password to be entered twice to catch typos.

    Subclasses should feel free to add any additional validation they
    need, but should take care when overriding ``save()`` to respect
    the ``commit=False`` argument, as several registration workflows
    will make use of it to create inactive user accounts.

    """
    phone = forms.CharField(required=False)

    def clean_phone(self):
        val = self.cleaned_data['phone']
        qs = User.objects.filter(phone=val, phone_verified=True)
        if qs.exists():
            raise forms.ValidationError(_('Пользователь с таким номером телефона уже зарегистрирован'))
        return val

    class Meta(UserCreationForm.Meta):
        fields = [
            'phone',
            'email',
            "password1",
            "password2",
        ]
        model = User

    error_css_class = "error"
    required_css_class = "required"

    def clean_phone(self):
        val = self.cleaned_data['phone']
        if val is None:
            return val
        if ''.join(val.split()) == '':
            return None
        val = re.sub('[^0-9]', '', val)
        if not val.startswith('+'):
            val = '+%s' % (val,)
        validate_international_phonenumber(val)
        qs = User.objects.filter(phone=val)
        if qs.exists():
            raise forms.ValidationError('Пользователь с таким телефоном уже зарегистрирован')
        self.cleaned_data['phone'] = val
        return val

    def clean_email(self):
        val = self.cleaned_data['email']
        qs = User.objects.filter(email=val)
        if qs.exists():
            raise forms.ValidationError('Пользователь с таким Email уже зарегистрирован')
        self.cleaned_data['email'] = val
        return val

    def clean(self):
        if 'phone' not in self.cleaned_data:
            self.cleaned_data['phone'] = self.data.get('phone', None)
            self.clean_phone()
        if 'email' not in self.cleaned_data:
            self.cleaned_data['email'] = self.data.get('email', None)
            self.clean_email()

        if not self.cleaned_data['phone'] and not self.cleaned_data['email']:
            raise forms.ValidationError("Телефон или E-mail обязательны")

    def save(self, commit=True):
        user = super().save(commit=False)

        if self.cleaned_data['phone'] is not None:
            user.username = self.cleaned_data['phone'].rstrip('+')
        elif self.cleaned_data['email'] is not None:
            user.username = self.cleaned_data['email']
        if commit:
            user.save()
        return user

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        email_field = User.get_email_field_name()
        if hasattr(self, "reserved_names"):
            reserved_names = self.reserved_names
        else:
            reserved_names = validators.DEFAULT_RESERVED_NAMES
        username_validators = [
            validators.ReservedNameValidator(reserved_names),
            validators.validate_confusables,
        ]
        self.fields[email_field].validators.extend(
            (validators.HTML5EmailValidator(), validators.validate_confusables_email)
        )
        self.fields[email_field].required = False


class RegistrationFormCaseInsensitive(RegistrationForm):
    """
    Subclass of ``RegistrationForm`` enforcing case-insensitive
    uniqueness of usernames.

    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields[User.USERNAME_FIELD].validators.append(
            validators.CaseInsensitiveUnique(
                User, User.USERNAME_FIELD, validators.DUPLICATE_USERNAME
            )
        )


class RegistrationFormTermsOfService(RegistrationForm):
    """
    Subclass of ``RegistrationForm`` which adds a required checkbox
    for agreeing to a site's Terms of Service.

    """

    tos = forms.BooleanField(
        widget=forms.CheckboxInput,
        label=_("I have read and agree to the Terms of Service"),
        error_messages={"required": validators.TOS_REQUIRED},
    )


class RegistrationFormUniqueEmail(RegistrationForm):
    """
    Subclass of ``RegistrationForm`` which enforces uniqueness of
    email addresses.

    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        email_field = User.get_email_field_name()
        self.fields[email_field].validators.append(
            validators.CaseInsensitiveUnique(
                User, email_field, validators.DUPLICATE_EMAIL
            )
        )


class SMSActivationForm(forms.Form):
    user = None
    code = forms.CharField(max_length=10, required=True, label=_('Код'),
                           help_text=_("Укажите код, высланный Вам в SMS"))

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)

    def clean_code(self):
        code = self.cleaned_data['code']
        qs = SMSActivationCode.objects.filter(user=self.user, code=code, )
        if not qs.exists():
            raise forms.ValidationError('Неверный код')
        code_obj = qs.first()
        return code

    def save(self):
        self.user.is_active = True
        self.user.phone_verified = True
        self.user.save()


class PhoneOrEmailLoginForm(forms.Form):
    phone_or_email = forms.CharField(max_length=255, label=_('Телефон или email'))
    password = forms.CharField(widget=forms.PasswordInput, label=_('Пароль'))
    username_field = 'phone_or_email'
    error_messages = {
        'invalid_login': _(
            "Please enter a correct %(username)s and password. Note that both "
            "fields may be case-sensitive."
        ),
        'inactive': _("This account is inactive."),
    }

    def clean_phone_or_email(self):
        val = self.cleaned_data['phone_or_email']
        val = ''.join(val.split())
        # if re.match(r'(\+)?\d+', val) and not val.startswith('+'):
        #     val
        return val

    def clean_password(self):
        passwd = self.cleaned_data['password']
        return passwd

    def __init__(self, request=None, *args, **kwargs):
        """
        The 'request' parameter is set for custom auth use by subclasses.
        The form data comes in via the standard 'data' kwarg.
        """
        self.request = request
        self.user_cache = None

        super().__init__(*args, **kwargs)

    def clean(self):
        phone_or_email = self.cleaned_data.get('phone_or_email')
        password = self.cleaned_data.get('password')

        if phone_or_email is not None and password:
            self.user_cache = authenticate(self.request, phone_or_email=phone_or_email, password=password)
            if self.user_cache is None:
                raise self.get_invalid_login_error()
            else:
                self.confirm_login_allowed(self.user_cache)

        return self.cleaned_data

    def confirm_login_allowed(self, user):
        """
        Controls whether the given User may log in. This is a policy setting,
        independent of end-user authentication. This default behavior is to
        allow login by active users, and reject login by inactive users.

        If the given user cannot log in, this method should raise a
        ``ValidationError``.

        If the given user may log in, this method should return None.
        """
        if not user.is_active:
            raise forms.ValidationError(
                self.error_messages['inactive'],
                code='inactive',
            )

    def get_user(self):
        return self.user_cache

    def get_invalid_login_error(self):
        return forms.ValidationError(
            self.error_messages['invalid_login'],
            code='invalid_login',
            params={'username': self.fields['phone_or_email'].label},
        )


class UpdateProfileForm(forms.ModelForm):
    photo_cropping = forms.CharField(required=False, widget=forms.HiddenInput(attrs={'class': 'cropping'}))
    photo = forms.IntegerField(required=False, widget=forms.HiddenInput)

    def __init__(self, *args, **kwargs):
        super(UpdateProfileForm, self).__init__(*args, **kwargs)
        user = self.instance
        try:
            self.instance.photo
        except UserPhoto.DoesNotExist:
            return
        self.fields['photo'].initial = user.photo.id
        self.fields['photo_cropping'].initial = user.photo.image_size()

    class Meta:
        model = User
        fields = ['first_name', 'phone', 'email', 'photo_cropping', 'photo']
        widgets = {}

    class Media:
        css = {
            'all': ('assets/css/vendors/dropzone.css',
                    'assets/css/vendors/image-cropper.css',
                    'forms/profile/update-profile.css')
        }
        js = ('assets/js/dropzone/dropzone.js',
              'assets/js/image-cropper/cropper.js',
              'forms/profile/update-profile.js')


class EmailConfirmationForm(forms.Form):
    uuid = forms.UUIDField(widget=forms.HiddenInput)
    user = None

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        initial = kwargs.get('initial', {})
        if 'uuid' not in initial:
            initial['uuid'] = self.user.uuid
        kwargs['initial'] = initial
        super(EmailConfirmationForm, self).__init__(*args, **kwargs)

    def save(self):
        item = EmailConfirmation.create(self.user)
        item.send()
        return item


class UserPhotoForm(forms.ModelForm):
    class Meta:
        fields = ['image_cropping']

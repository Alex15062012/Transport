from django.db import models
from django.contrib.auth.models import AbstractUser
from phonenumber_field.modelfields import PhoneNumberField
from django.utils.translation import ugettext_lazy as _
import string
import random
from datetime import timedelta
from django.conf import settings
from django.utils.timezone import now
from django.contrib.auth.validators import UnicodeUsernameValidator
from django.db import transaction
from django import forms
from django.urls import reverse
from django.db.models import signals
from .hooks import hookset
from django.contrib.sites.models import Site
import uuid
from django.template.loader import render_to_string
import os
from django.contrib.postgres.fields import ArrayField
from . import signals
from PIL import Image


def get_user_photo_upload_path(instance, filename):
    path = os.path.join(
        'users', "%s" % instance.user.uuid, filename)
    disk_path = os.path.join(settings.MEDIA_ROOT, path)
    if not os.path.isdir(os.path.dirname(disk_path)):
        os.makedirs(os.path.dirname(disk_path))
    return path


# noinspection DuplicatedCode
class UserPhoto(models.Model):
    image = models.ImageField(null=True, upload_to=get_user_photo_upload_path, blank=True)
    image_cropping = ArrayField(models.IntegerField(), size=4, null=True, blank=True)
    user = models.OneToOneField('User', related_name='photo', on_delete=models.CASCADE, null=True)

    def url(self):
        try:
            return self.image.url
        except Exception as e:
            print(e)

    def cropped_image(self, refresh=False):
        if self.image_cropping is None:
            return self.image.url
        try:
            dn, fn = os.path.split(self.image.path)
            cropped_dn = os.path.join(dn, 'cropped')
            if not os.path.isdir(cropped_dn):
                os.makedirs(cropped_dn)
            cropped_fn = os.path.join(cropped_dn, fn)
            if os.path.isfile(cropped_fn) and not refresh:
                return cropped_fn.replace(str(settings.MEDIA_ROOT), settings.MEDIA_URL.rstrip('/'))
            im = Image.open(self.image.path)
            cropped_im = im.crop(self.image_cropping)
            cropped_im.save(cropped_fn)
            return cropped_fn.replace(str(settings.MEDIA_ROOT), settings.MEDIA_URL.rstrip('/'))
        except Exception as e:
            print(e)
            return self.image.url

    def image_size(self):
        try:
            im = Image.open(self.image.path)
            return list(im.size)
        except:
            return


class User(AbstractUser):
    username_validator = UnicodeUsernameValidator()
    phone = PhoneNumberField(blank=True, null=True, verbose_name='Телефон')
    phone_verified = models.BooleanField(default=False, verbose_name="Телефон проверен")
    email_verified = models.BooleanField(default=False, verbose_name="Email проверен")
    uuid = models.UUIDField(default=uuid.uuid4)
    email = models.EmailField(_('email address'), blank=True, null=True)

    def has_photo(self):
        try:
            self.photo
            return True
        except UserPhoto.DoesNotExist:
            return False

    def queue_activation_sms(self, template='accounts/sms/sms_activation.txt'):
        if self.phone is None:
            return
        qs = SMSActivationCode.objects.filter(
            created_at__gt=now()-timedelta(seconds=settings.SMS_VALIDITY_DURATION),
            created_at__lt=now()-timedelta(seconds=settings.SMS_SEND_INTERVAL),
            user=self,
        )
        if qs.exists():
            item = qs.first()
            from app.models import SMSQueue
            if item.sms is None:
                item.queue_sms(template)
                return item
            return False
        code = ''.join(random.choices(string.digits, k=settings.SMS_ACTIVATION_CODE_LENGTH))
        code = SMSActivationCode.objects.create(code=code, user=self, created_at=now())
        item = code.queue_sms(template)
        return item


class SMSActivationCode(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    is_sent = models.BooleanField(default=False)
    sent_at = models.DateTimeField(null=True)
    code = models.CharField(max_length=10)
    sms = models.OneToOneField('app.SMSQueue', blank=True, null=True, related_name='activation_code',
                               on_delete=models.SET_NULL)

    def sms_text(self, tpl='accounts/sms/sms_activation.txt'):
        ctx = {'code': self.code}
        text = render_to_string(tpl, ctx).strip()
        return text

    def queue_sms(self, tpl='accounts/sms/sms_activation.txt'):
        from app.models import SMSQueue
        item = SMSQueue.objects.create(user=self.user, text=self.sms_text(tpl), created_at=now())
        self.sms = item
        self.save()
        return item


class EmailConfirmationManager(models.Manager):

    def delete_expired_confirmations(self):
        for confirmation in self.all():
            if confirmation.key_expired():
                confirmation.delete()


class EmailConfirmation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    created = models.DateTimeField(default=now)
    sent = models.DateTimeField(null=True)
    key = models.CharField(max_length=128, unique=True)

    objects = EmailConfirmationManager()

    class Meta:
        verbose_name = _("email confirmation")
        verbose_name_plural = _("email confirmations")

    def __str__(self):
        return "confirmation for {0}".format(self.user.email)

    @classmethod
    def create(cls, user):
        key = hookset.generate_email_confirmation_token(user.email)
        return cls._default_manager.create(user=user, key=key)

    def key_expired(self):
        expiration_date = self.sent + timedelta(days=settings.ACCOUNTS_EMAIL_CONFIRMATION_EXPIRE_DAYS)
        return expiration_date <= now()
    key_expired.boolean = True

    def confirm(self):
        if not self.key_expired() and not self.user.email_verified:
            return

    def send(self, **kwargs):
        current_site = kwargs["site"] if "site" in kwargs else Site.objects.get_current()
        protocol = settings.ACCOUNTS_DEFAULT_HTTP_PROTOCOL
        activate_url = "{0}://{1}{2}".format(
            protocol,
            current_site.domain,
            reverse(settings.ACCOUNTS_EMAIL_CONFIRMATION_URL, args=[self.key])
        )
        ctx = {
            "email_address": self.user.email,
            "user": self.user,
            "activate_url": activate_url,
            "current_site": current_site,
            "key": self.key,
        }
        hookset.send_confirmation_email([self.user.email], ctx)
        self.sent = now()
        self.save()
        signals.email_confirmation_sent.send(sender=self.__class__, confirmation=self)

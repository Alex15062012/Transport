from django.core.management.base import BaseCommand
from ...models import SMSQueue
from time import sleep
from huawei_lte_api.Connection import Connection
from huawei_lte_api.enums.sms import TextModeEnum
from huawei_lte_api.Client import Client
from django.conf import settings
from django.utils.timezone import now


class Command(BaseCommand):
    help = "My shiny new management command."

    def handle(self, *args, **options):
        while True:
            if not SMSQueue.objects.filter(sent_at__isnull=True, phone_invalid=False).exists():
                sleep(2)
                continue
            conn = Connection(settings.SMS_MODEM_URL, settings.SMS_USERNAME, settings.SMS_PASSWORD)
            client = Client(connection=conn)
            for m in SMSQueue.objects.filter(sent_at__isnull=True, phone_invalid=False)[:50]:
                try:
                    res = client.sms.send_sms([m.user.phone], m.text, text_mode=TextModeEnum.UCS2)
                    m.sent_at = now()
                    m.save()
                    print(res, m.text, m.sent_at, m.user.phone)
                except Exception as e:
                    m.phone_invalid = True
                    m.save()
                    print(e)
                    continue

            conn.close()
            sleep(1)
            continue


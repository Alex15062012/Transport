"""
URLconf for registration and activation, using django-registration's
HMAC activation workflow.

"""

from django.urls import path
from django.views.generic.base import TemplateView
from django.contrib.auth.views import LogoutView

from . import views

urlpatterns = [
    path(
        "activate/complete/",
        TemplateView.as_view(
            template_name="accounts/activation_complete.html"
        ),
        name="accounts_activation_complete",
    ),
    path(
        'activate/sms/', views.SMSActivationView.as_view(),
        name='accounts_sms_activation'
    ),
    path("confirm_email/<str:key>/",
         views.ConfirmEmailView.as_view(),
         name="accounts_confirm_email"),
    path(
        "activate/<str:activation_key>/",
        views.ActivationView.as_view(),
        name="accounts_activate",
    ),
    path(
        "register/",
        views.RegistrationView.as_view(),
        name="accounts_register",
    ),
    path(
        "register/complete/",
        TemplateView.as_view(
            template_name="accounts/registration_complete.html"
        ),
        name="accounts_registration_complete",
    ),
    path(
        "register/closed/",
        TemplateView.as_view(
            template_name="accounts/registration_closed.html"
        ),
        name="accounts_registration_disallowed",
    ),
    path('profile/edit/', views.UpdateProfileView.as_view(), name='update-profile'),
    path('profile/upload-photo/', views.upload_profile_photo, name='upload-profile-photo'),
    path('profile/create-email-confirmation/', views.EmailConfirmationCreateView.as_view(),
         name='create-email-confirmation'),
    path('profile/create-phone-confirmation/', views.send_verification_sms, name='create-phone-confirmation'),
    path('profile/verify-phone/', views.confirm_phone, name='verify-phone'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(template_name='accounts/logout.html'), name='logout')

]

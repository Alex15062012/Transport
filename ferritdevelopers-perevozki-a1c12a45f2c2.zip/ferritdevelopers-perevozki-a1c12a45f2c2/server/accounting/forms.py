from django import forms
from .models import Transaction


class TransactionCreateForm(forms.ModelForm):
    user = None

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(TransactionCreateForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        print()
        item = super().save(commit=False)
        item.user = self.user
        if commit:
            item.save()
        return item

    class Meta:
        model = Transaction
        fields = ['amount', 'tariff']

import json
import os
from django.http import HttpResponseRedirect, JsonResponse, Http404, HttpResponseForbidden, HttpResponseBadRequest
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.contrib.auth import login as auth_login
from django.views.generic.edit import FormView, UpdateView
from django.views.generic.base import TemplateResponseMixin, View
from .forms import SMSActivationForm, PhoneOrEmailLoginForm as LoginForm, UpdateProfileForm
from .models import User, UserPhoto, SMSActivationCode
from django.contrib import messages
from django.shortcuts import redirect
from . import signals
from .exceptions import ActivationError
from .forms import RegistrationForm, EmailConfirmationForm
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.sites.shortcuts import get_current_site
from django.core import signing
from django.template.loader import render_to_string
from django.urls import reverse_lazy, reverse
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now
from django_registration import signals
from django_registration.exceptions import ActivationError
from django_registration.views import ActivationView as BaseActivationView
from django_registration.views import RegistrationView as BaseRegistrationView
from django.contrib.auth import login
from .models import EmailConfirmation
from PIL import Image
from datetime import timedelta

USER_MODEL_MISMATCH = """
You are attempting to use the registration view {view}
with the form class {form},
but the model used by that form ({form_model}) is not
your Django installation's user model ({user_model}).

Most often this occurs because you are using a custom user model, but
forgot to specify a custom registration form class for it. Specifying
a custom registration form class is required when using a custom user
model. Please see django-registration's documentation on custom user
models for more details.
"""


"""
A two-step (registration followed by activation) workflow, implemented
by emailing an HMAC-verified timestamped activation token to the user
on signup.

"""

REGISTRATION_SALT = getattr(settings, "REGISTRATION_SALT", "registration")


class RegistrationView(BaseRegistrationView):
    """
    Register a new (inactive) user account, generate an activation key
    and email it to the user.

    This is different from the model-based activation workflow in that
    the activation key is the username, signed using Django's
    TimestampSigner, with HMAC verification on activation.

    """

    email_body_template = "accounts/email/activation_email_body.txt"
    email_subject_template = "accounts/email/activation_email_subject.txt"
    success_url = reverse_lazy("accounts_registration_complete")
    form_class = RegistrationForm
    template_name = 'accounts/registration_form.html'
    is_sms = False

    def get_success_url(self, user=None):
        if self.is_sms:
            return reverse_lazy('accounts_sms_activation')
        return super().get_success_url(user=user)

    def register(self, form):
        new_user = self.create_inactive_user(form)
        signals.user_registered.send(
            sender=self.__class__, user=new_user, request=self.request
        )
        return new_user

    def create_inactive_user(self, form):
        """
        Create the inactive user account and send an email containing
        activation instructions.

        """
        new_user = form.save(commit=False)
        new_user.is_active = False
        if new_user.phone is not None:
            new_user.username = str(new_user.phone).rstrip('+')

        new_user.save()
        if new_user.phone is not None:
            new_user.queue_activation_sms()
            self.is_sms = True
            self.request.session['uid'] = new_user.id
            if new_user.email is not None:
                self.send_activation_email(new_user)
        else:
            self.send_activation_email(new_user)
        return new_user

    def get_activation_key(self, user):
        """
        Generate the activation key which will be emailed to the user.

        """
        return signing.dumps(obj=user.get_username(), salt=REGISTRATION_SALT)

    def get_email_context(self, activation_key):
        """
        Build the template context used for the activation email.

        """
        scheme = "https" if self.request.is_secure() else "http"
        current_site = get_current_site(self.request)
        activate_url = "{0}://{1}{2}".format(
            scheme,
            current_site.domain,
            reverse(settings.ACCOUNTS_EMAIL_CONFIRMATION_URL, args=[activation_key])
        )

        return {
            "scheme": scheme,
            "activation_key": activation_key,
            "expiration_days": settings.ACCOUNTS_ACTIVATION_DAYS,
            "site": current_site,
            'activate_url': activate_url
        }

    def send_activation_email(self, user):
        """
        Send the activation email. The activation key is the username,
        signed using TimestampSigner.

        """
        activation_key = self.get_activation_key(user)
        context = self.get_email_context(activation_key)
        context["user"] = user
        print('context', context)
        subject = render_to_string(
            template_name=self.email_subject_template,
            context=context,
            request=self.request,
        )
        # Force subject to a single line to avoid header-injection
        # issues.
        subject = "".join(subject.splitlines())
        message = render_to_string(
            template_name=self.email_body_template,
            context=context,
            request=self.request,
        )
        print(subject, message)

        user.email_user(subject, message, settings.DEFAULT_FROM_EMAIL)
        EmailConfirmation.objects.create(key=activation_key.lower(), user=user, sent=now())


class ActivationView(BaseActivationView):
    """
    Given a valid activation key, activate the user's
    account. Otherwise, show an error message stating the account
    couldn't be activated.

    """

    ALREADY_ACTIVATED_MESSAGE = _(
        "The account you tried to activate has already been activated."
    )
    BAD_USERNAME_MESSAGE = _("The account you attempted to activate is invalid.")
    EXPIRED_MESSAGE = _("This account has expired.")
    INVALID_KEY_MESSAGE = _("The activation key you provided is invalid.")
    success_url = reverse_lazy("home")

    def activate(self, *args, **kwargs):
        username = self.validate_key(kwargs.get("activation_key"))
        user = self.get_user(username)
        user.is_active = True
        user.save()
        login(self.request, user)
        return user

    def validate_key(self, activation_key):
        """
        Verify that the activation key is valid and within the
        permitted activation time window, returning the username if
        valid or raising ``ActivationError`` if not.

        """
        try:
            username = signing.loads(
                activation_key,
                salt=REGISTRATION_SALT,
                max_age=settings.ACCOUNTS_ACTIVATION_DAYS * 86400,
            )
            return username
        except signing.SignatureExpired:
            raise ActivationError(self.EXPIRED_MESSAGE, code="expired")
        except signing.BadSignature:
            raise ActivationError(
                self.INVALID_KEY_MESSAGE,
                code="invalid_key",
                params={"activation_key": activation_key},
            )

    def get_user(self, username):
        """
        Given the verified username, look up and return the
        corresponding user account if it exists, or raising
        ``ActivationError`` if it doesn't.

        """
        User = get_user_model()
        try:
            user = User.objects.get(**{User.USERNAME_FIELD: username})
            if user.is_active:
                raise ActivationError(
                    self.ALREADY_ACTIVATED_MESSAGE, code="already_activated"
                )
            return user
        except User.DoesNotExist:
            raise ActivationError(self.BAD_USERNAME_MESSAGE, code="bad_username")


class SMSActivationView(FormView):
    template_name = 'accounts/sms_activation.html'
    form_class = SMSActivationForm
    _user = None

    def get_form_kwargs(self):
        data = super().get_form_kwargs()
        uid = self.request.session.get('uid', None)
        self._user = User.objects.get(id=uid)
        data['user'] = self._user
        return data

    def form_valid(self, form):
        form.save()
        login(self.request, self._user)
        return super(SMSActivationView, self).form_valid(form)

    def get_success_url(self):
        return reverse('home')


class LoginView(FormView):
    form_class = LoginForm
    template_name = 'accounts/login.html'
    redirect_authenticated_user = False

    @method_decorator(sensitive_post_parameters())
    @method_decorator(csrf_protect)
    @method_decorator(never_cache)
    def dispatch(self, request, *args, **kwargs):
        if self.redirect_authenticated_user and self.request.user.is_authenticated:
            redirect_to = self.get_success_url()
            if redirect_to == self.request.path:
                raise ValueError(
                    "Redirection loop for authenticated user detected. Check that "
                    "your LOGIN_REDIRECT_URL doesn't point to a login page."
                )
            return HttpResponseRedirect(redirect_to)
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        _next = self._get_next_url()
        return _next

    def form_valid(self, form):
        """Security check complete. Log the user in."""
        auth_login(self.request, form.get_user())
        return HttpResponseRedirect(self.get_success_url())

    def _get_next_url(self):
        _next = self.request.GET.get('next', None)
        if _next is None:
            return '/'
        return _next


@method_decorator(login_required, name='dispatch')
class UpdateProfileView(UpdateView):
    form_class = UpdateProfileForm
    template_name = 'accounts/update_profile.html'

    def get_success_url(self):
        return reverse('home')

    def form_valid(self, form):
        item = form.save()
        photo_id = self.request.POST.get('photo')
        photo = UserPhoto.objects.get(id=photo_id, user=self.request.user)
        cropping = self.request.POST.get('photo_cropping')
        try:
            cropping = json.loads(cropping)
            photo.image_cropping = cropping
        except ValueError:
            cropping = None
        photo.save()
        photo.refresh_from_db()
        messages.success(self.request, 'Профиль сохранен')
        return HttpResponseRedirect(self.get_success_url())

    def get_object(self, queryset=None):
        return self.request.user

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['email_confirmation_form'] = EmailConfirmationForm(user=self.request.user)
        return ctx


def upload_profile_photo(request):
    if request.method == 'POST':
        if request.FILES.get('image', None) is not None:
            paths = []
            for p in UserPhoto.objects.filter(user=request.user):
                try:
                    paths.append(p.image.path)
                except ValueError:
                    pass
            UserPhoto.objects.filter(user=request.user).delete()
            for p in paths:
                os.remove(p)
            print(request.FILES)
            im = request.FILES.get('image')
            photo = UserPhoto.objects.create(image=im, user=request.user)
            im = Image.open(photo.image.path)
            # photo.image.save(im.name, im)
            return JsonResponse({'id': photo.id, 'url': photo.image.url, 'size': im.size})
        if request.POST.get('cropping', None):
            p = UserPhoto.objects.get(id=request.POST.get('id'))
            p.image_cropping = request.POST.get('cropping', None)
            p.save()
    return JsonResponse({'post': False}, status=400)


class ConfirmEmailView(TemplateResponseMixin, View):

    http_method_names = ["get", "post"]
    messages = {
        "email_confirmed": {
            "level": messages.SUCCESS,
            "text": _("You have confirmed {email}.")
        },
        "email_confirmation_expired": {
            "level": messages.ERROR,
            "text": _("Email confirmation for {email} has expired.")
        }
    }

    def get_template_names(self):
        return {
            "GET": ["accounts/email_confirm.html"],
            "POST": ["accounts/email_confirmed.html"],
        }[self.request.method]

    def get(self, *args, **kwargs):
        self.object = self.get_object()
        ctx = self.get_context_data()
        return self.render_to_response(ctx)

    def post(self, *args, **kwargs):
        self.object = confirmation = self.get_object()
        self.user = self.request.user
        confirmed = confirmation.confirm() is not None
        if confirmed:
            self.after_confirmation(confirmation)
            if settings.ACCOUNTS_EMAIL_CONFIRMATION_AUTO_LOGIN:
                self.user = self.login_user(confirmation.email_address.user)
            redirect_url = self.get_redirect_url()
            if not redirect_url:
                ctx = self.get_context_data()
                return self.render_to_response(ctx)
            if self.messages.get("email_confirmed"):
                messages.add_message(
                    self.request,
                    self.messages["email_confirmed"]["level"],
                    self.messages["email_confirmed"]["text"].format(**{
                        "email": confirmation.email_address.email
                    })
                )
        else:
            redirect_url = self.get_redirect_url()
            messages.add_message(
                self.request,
                self.messages["email_confirmation_expired"]["level"],
                self.messages["email_confirmation_expired"]["text"].format(**{
                    "email": confirmation.user.email
                })
            )
        return redirect(redirect_url)

    def get_object(self, queryset=None):
        if queryset is None:
            queryset = self.get_queryset()
        try:
            item = queryset.get(key=self.kwargs["key"].lower())
            user = item.user
            user.email_verified = True
            user.is_active = True
            user.save()
            return item
        except EmailConfirmation.DoesNotExist:
            raise Http404()

    def get_queryset(self):
        qs = EmailConfirmation.objects.all()
        qs = qs.select_related("user")
        return qs

    def get_context_data(self, **kwargs):
        ctx = kwargs
        ctx["confirmation"] = self.object
        return ctx

    def get_redirect_url(self):
        if self.user.is_authenticated:
            if not settings.ACCOUNTS_EMAIL_CONFIRMATION_AUTHENTICATED_REDIRECT_URL:
                return settings.ACCOUNTS_LOGIN_REDIRECT_URL
            return settings.ACCOUNTS_EMAIL_CONFIRMATION_AUTHENTICATED_REDIRECT_URL
        else:
            return settings.ACCOUNTS_EMAIL_CONFIRMATION_ANONYMOUS_REDIRECT_URL

    def after_confirmation(self, confirmation):
        user = confirmation.user
        user.is_active = True
        user.email_verified = True
        user.save()

    def login_user(self, user):
        user.backend = "django.contrib.auth.backends.ModelBackend"
        login(self.request, user)
        return user


class EmailConfirmationCreateView(FormView):
    form_class = EmailConfirmationForm
    template_name = 'accounts/email_confirmation.html'

    def get_form_kwargs(self):
        data = super().get_form_kwargs()
        data['user'] = self.request.user
        return data

    def dispatch(self, request, *args, **kwargs):
        uuid = request.POST.get('uuid', None)
        if not str(request.user.uuid) == uuid:
            return HttpResponseForbidden('')
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        return reverse('update-profile')

    def get_initial(self):
        return {'uuid': self.request.user.uuid}

    def form_valid(self, form):
        try:
            form.save()
            messages.success(self.request, 'Письмо с подтверждением было отправлено на адрес  %s'
                             % (self.request.user.email,))
        except Exception as e:
            print(e)
            messages.error(self.request,
                           'Невозможно отправить письмо на адрес  %s' % (self.request.user.email,))
        return HttpResponseRedirect(self.get_success_url())


def send_verification_sms(request):
    user = request.user
    res = user.queue_activation_sms(template='accounts/sms/phone_confirm.txt')
    if res:
        return JsonResponse({'js_time': int(now().timestamp()*1000), 'ok': True})
    return JsonResponse({'js_time': int(now().timestamp()*1000), 'ok': False}, status=400)


def confirm_phone(request):
    if not request.method == 'POST':
        return HttpResponseBadRequest('')
    code = request.POST.get('code', None)
    qs = SMSActivationCode.objects.filter(code=code, user=request.user,
                                          created_at__gt=now()-timedelta(seconds=300))
    if not qs.exists():
        return JsonResponse({'ok': False})
    user = request.user
    user.phone_verified = True
    user.save()
    return JsonResponse({'ok': True})

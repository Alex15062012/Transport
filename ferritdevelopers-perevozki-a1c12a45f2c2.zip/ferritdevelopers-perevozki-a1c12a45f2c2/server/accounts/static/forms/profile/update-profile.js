Dropzone.autoDiscover = false;
$(document).ready(function () {
  let cropper, imageWidth, ratio, initialBox;
  const initCropper = function (){
    cropper = $('#crop-image').cropper({
      aspectRatio: 3 / 4,
      zoom: false,
      crop: function (evt) {
        if(initialBox !== undefined){
          $('#crop-image').cropper('setCropBoxData', initialBox)
          initialBox = undefined
          return;
        }
        let data = evt.detail;
        let corners = [data.x, data.y, data.x + data.width, data.y + data.height]
        $('#id_photo_cropping').val(JSON.stringify(corners))
      },

    })
  }

  const dz = new Dropzone('#photo-dropzone', {
    url: '/accounts/profile/upload-photo/',
    parallelUploads: 1,
    paramName: 'image',
    maxFiles: 99,
    maxFilesize: 10,
    acceptedFiles: 'image/*',
    headers: {
      'X-CSRFToken': $('input[name="csrfmiddlewaretoken"]').val()
    },
    previewsContainer: '#dropzone-preview',
    init: function () {
      this.on("success", function (file, resp) {
        $('#id_photo').val(resp.id);
        $('#crop-image').cropper('destroy')
        $('#crop-image').attr('src', resp.url);
        imageWidth = resp.size[0]
        initCropper()
      });
    }
  });
  if($('#crop-image').attr('src')){
    let originalSize = JSON.parse($('#crop-image').attr('data-size')), width = $('#crop-image').width()
    ratio = originalSize[0]/width;
    let boxPosition = JSON.parse($('#crop-image').attr('data-cropping'))
    for(let c=0;c<boxPosition.length;c++){
      boxPosition[c] = boxPosition[c]/ratio;
    }
    initialBox = {left: boxPosition[0], top: boxPosition[1], width: boxPosition[2]-boxPosition[0],
      height: boxPosition[3]-boxPosition[1]};
    imageWidth = originalSize[0];
    initCropper();
    setTimeout(function () {

    }, 500)
    $(document).on('built.cropper', function (){alert('1')})

  }
  let smsTimer = 60, smsURL = $('#confirmation-code').attr('data-url'), timerInterval,
    verificationURL = $('#verify-phone').attr('data-url');
  setInterval(function () {
    $('#timer').text(smsTimer);
  })
  function request_sms(){
    $.get(smsURL, function (resp) {
      $('#resend-code').attr('disabled', true);
      smsTimer = 60
      console.log(resp)
      timerInterval = setInterval(function () {
        if(smsTimer == 0) {
          $('#resend-code').removeAttr('disabled');
          clearInterval(timerInterval)
          return
        }
        smsTimer--;
      }, 1000)
    });
  }
  $(document).on('click', '#verify-phone', function () {
    $.ajax({
      url: verificationURL,
      type: 'post',
      data: {
        code: $('#confirmation-code').val()
        },
      headers: {
        'X-CSRFToken': $('input[name="csrfmiddlewaretoken"]').val()
      },
      dataType: 'json',
      success: function (data) {
        if (data.ok){
          $('#phone-invalid').parent().html('<i class="icofont icofont-check-circled"></i>')
        }
      }
    });
  })
  $(document).on('click', '#resend-code', function f() {
    request_sms();
  })
  const smsModal = document.getElementById('modal-phone-confirm');
  smsModal.addEventListener('show.bs.modal', request_sms);

})

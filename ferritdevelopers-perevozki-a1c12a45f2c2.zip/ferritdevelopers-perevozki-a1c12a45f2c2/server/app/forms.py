from django import forms
import json
from .models import CheckPoint, JobOrder, SEARCH_MODE_CHOICES, FORM_FIELD_CHOICES, Vehicle, CheckPointTemplate, Truck, \
    TruckType, VehicleState, RoutePoint, ROUTE_POINT_TYPE_CHOICES, CargoMoveOrder, VehiclePhoto, ORDER_PARTIAL_CHOICES
from django.utils.translation import ugettext_lazy as _
from django.contrib.contenttypes.models import ContentType
from django.db.models import Q
from django.utils.timezone import now
from django.conf import settings
from django.contrib.gis import forms as gis_forms
from django.contrib.gis.geos import GEOSGeometry

from django.contrib.gis.forms.widgets import OSMWidget


class CheckPointForm(forms.ModelForm):
    user = None

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('owner', None)
        super().__init__(*args, **kwargs)


class JobOrderForm(forms.ModelForm):
    user = None
    # start_address = forms.CharField(max_length=255, label='Точка начала')
    # start_latitude = forms.FloatField(widget=forms.HiddenInput)
    # start_longitude = forms.FloatField(widget=forms.HiddenInput)
    # end_address = forms.CharField(max_length=255, label='Куда')

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('client', None)
        super().__init__(*args, **kwargs)
        self.fields['notify'].help_text = 'При установке отметки будет оповещено %s исполнителей, ' \
                                          'и с Вашего счета спишется %sруб.' \
                                          % (getattr(settings, 'NOTIFICATIONS_PER_ORDER_DEFAULT', 10),
                                             getattr(settings, 'JOB_ORDER_NOTIFICATION_COST', 50)
                                             )
        self.fields['status'].choices = ORDER_PARTIAL_CHOICES

    def save(self, commit=True):
        item = super().save(commit=False)
        item.client = self.user
        if commit:
            item.save()
        return item

    class Meta:
        model = JobOrder
        fields = ['notify', 'note', 'status']
        widgets = {'status': forms.RadioSelect}


class VehicleForm(forms.ModelForm):
    photo_cropping = forms.CharField(required=False, widget=forms.HiddenInput(attrs={'class': 'cropping'}))
    _user = None
    _category = None
    _attribute_values = []
    extra_fields = []

    def __init__(self, *args, **kwargs):
        self._user = kwargs.pop('user', None)
        self._category = kwargs.pop('category', None)
        super().__init__(*args, **kwargs)

    def save(self, commit=True):
        item = super().save(commit=False)
        item.owner = self._user
        item.save()
        item.category = self._category
        if self.cleaned_data.get('photo_cropping', None):
            photo_cropping = self.cleaned_data.get('photo_cropping', None)
            try:
                photo_cropping = json.loads(photo_cropping)
                try:
                    photo = VehiclePhoto.objects.get(vehicle=item)
                    photo.image_cropping = photo_cropping
                    photo.save()
                except VehiclePhoto.DoesNotExist:
                    pass
            except ValueError:
                pass
        if commit:
            item.save()
        return item

    class Meta:
        model = Vehicle
        fields = ['name', 'photo_cropping']


class CheckPointForm(forms.ModelForm):
    _owner = None
    _vehicle = None

    def __init__(self, *args, **kwargs):
        self._owner = kwargs.pop('owner')
        self._vehicle = kwargs.pop('vehicle')
        super().__init__(*args, **kwargs)
        self.fields['vehicle'].queryset = Vehicle.objects.filter(owner=self._owner)

        meta_fields = []

        for p in self._vehicle.category.attributes.all():
            if p.accept_offer_mode in ['allow_less', 'allow_more']:
                attr_name = 'param_accept_%s' % (p.id,)
                if p.accept_offer_mode == 'allow_less':
                    lbl = _('Принимать меньше для %s' % (p.name,))
                elif p.accept_offer_mode == 'allow_more':
                    lbl = _('Принимать больше для %s' % (p.name,))
                element = forms.BooleanField(label=lbl)
                setattr(self, attr_name, element)
                self.fields[attr_name] = element
                meta_fields.append(attr_name)
        self._meta.fields += meta_fields

    def save(self, commit=True):
        item = super().save(commit)
        CheckPoint.objects.filter(vehicle=item.vehicle)\
            .filter(Q(valid_until__isnull=True) | Q(valid_until__gte=now())).update(valid_until=now())
        if item.is_template:
            keys = ['owner', 'vehicle', 'address', 'latitude', 'longitude']
            kwargs = {}
            for k in keys:
                val = getattr(item, k, None)
                if val is None:
                    break
                kwargs[k] = val
            if len(kwargs) == len(keys):
                CheckPointTemplate.objects.get_or_create(**kwargs)
        return item

    class Meta:
        model = CheckPoint
        fields = ['vehicle', 'is_template', 'address', 'latitude', 'longitude', 'valid_until']
        widgets = {'latitude': forms.HiddenInput, 'longitude': forms.HiddenInput, 'vehicle': forms.HiddenInput,
                   'address': forms.TextInput, }


class SelectTemplateForm(forms.Form):
    vehicle = None
    template = forms.ModelChoiceField(queryset=CheckPointTemplate.objects.none(), label='Ранее сохраненные точки')

    def __init__(self, *args, **kwargs):
        self.vehicle = kwargs.pop('vehicle')
        super(SelectTemplateForm, self).__init__(*args, **kwargs)
        self.fields['template'].queryset = CheckPointTemplate.objects.filter(vehicle=self.vehicle)


class TruckForm(forms.ModelForm):
    user = None
    category = None
    vehicle = None
    template_name = 'app/partials/vehicle_forms/truck_form.html'

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        self.category = kwargs.pop('category', None)
        self.vehicle = kwargs.pop('vehicle', None)

        super(TruckForm, self).__init__(*args, **kwargs)
        self.fields['type'].queryset = TruckType.objects.filter(element=TruckType.DDL)
        self.fields['type2'].queryset = TruckType.objects.filter(element=TruckType.RSB)

    def save(self, commit=True):
        item = super(TruckForm, self).save(True)
        if item.id is not None:
            if item.vehicle is None:
                ct = ContentType.objects.get_for_model(Truck)
                if self.vehicle is not None:
                    item.vehicle = self.vehicle
                else:
                    v = Vehicle.objects.get_or_create(owner=self.user, category=self.category, content_type=ct,
                                                      object_id=item.id)[0]
                    item.vehicle = v
        if commit:
            item.save()
        return item

    class Meta:
        model = Truck
        fields = ['type', 'type2', 'loading_types', 'load_capacity', 'load_volume',
                  'length', 'width', 'height', 'trailer_length',
                  'trailer_width', 'trailer_height']
        widgets = {'type2': forms.RadioSelect, 'loading_types': forms.CheckboxSelectMultiple}

    class Media:
        css = {
            'all': ('assets/css/vendors/dropzone.css',
                    'assets/css/vendors/image-cropper.css',
                    'forms/vehicle_form.css')
        }
        js = ('assets/js/dropzone/dropzone.js',
              'assets/js/image-cropper/cropper.js',
              'forms/vehicle_form.js')


class DateTimePickerInput(forms.DateTimeInput):
    input_type = 'datetime-local'


class VehicleStateForm(forms.ModelForm):
    owner = None
    vehicle = None
    route = forms.CharField(widget=forms.Textarea, required=False)

    def __init__(self, *args, **kwargs):
        self.owner = kwargs.pop('owner', None)
        self.vehicle = kwargs.pop('vehicle', None)
        super().__init__(*args, **kwargs)

    def clean_route(self):
        val = self.cleaned_data['route']
        if not val:
            self.cleaned_data['route'] = None
            return None
        json_data = json.loads(val)
        res = []
        for x in json_data:
            res.append(' '.join([str(_) for _ in x]))
        res = 'MULTIPOINT(%s)' % (','.join(res),)
        self.cleaned_data['route'] = res
        return res

    def save(self, commit=True):
        item = super().save(commit=False)
        item.vehicle = self.vehicle
        item.owner = self.owner
        if commit:
            item.save()
        return item

    class Meta:
        model = VehicleState
        fields = ['is_static', 'upload', 'load_radius', 'unload_radius', 'starts_at', 'ends_at',
                  'route', 'distance'
                  ]
        widgets = {'starts_at': DateTimePickerInput, 'ends_at': DateTimePickerInput,
                   'distance': forms.HiddenInput
                   }

    class Media:
        css = {'all': (
            'assets/js/leaflet/leaflet.css',
            'assets/js/leaflet-routing-machine-3.2.12/dist/leaflet-routing-machine.css',
            'forms/checkpoint.css'
                       )
               }
        js = (
            'assets/js/leaflet/leaflet.js',
            'assets/js/leaflet-routing-machine-3.2.12/dist/leaflet-routing-machine.js',
            'forms/checkpoint.js'
        )


class RoutePointForm(forms.ModelForm):
    # type = forms.ChoiceField(choices=ROUTE_POINT_TYPE_CHOICES, widget=forms.RadioSelect())

    def __init__(self, *args, **kwargs):
        self.owner = kwargs.pop('owner', None)
        self.vehicle = kwargs.pop('vehicle', None)
        self.state = kwargs.pop('state', None)
        super().__init__(*args, **kwargs)

    def save(self, commit=True):
        item = super(RoutePointForm, self).save(commit=False)
        item.owner = self.owner
        item.vehicle = self.vehicle
        item.state = self.state
        if commit:
            item.save()
        return item

    class Meta:
        model = RoutePoint
        fields = ['address', 'latitude', 'longitude']
        widgets = {'latitude': forms.HiddenInput, 'longitude': forms.HiddenInput,
                   'address': forms.TextInput(attrs={'class': 'address'})}


class CargoMoveOrderForm(forms.ModelForm):
    owner = None

    def __init__(self, *args, **kwargs):
        self.owner = kwargs.pop('owner', None)
        super(CargoMoveOrderForm, self).__init__(*args, **kwargs)

    class Meta:
        model = CargoMoveOrder
        fields = ['weight', 'volume', 'cargo_type', 'cargo_type_text', 'load_time',
                  # 'valid_duration',
                  'truck_types', 'loading_types', 'unloading_types', 'price_card',
                  'price_cache', 'price_uom', 'price_bank', 'distance']
        widgets = {'loading_types': forms.CheckboxSelectMultiple, 'unloading_types': forms.CheckboxSelectMultiple,
                   'truck_types': forms.CheckboxSelectMultiple, 'payment_variants': forms.CheckboxSelectMultiple,
                   'distance': forms.HiddenInput(attrs={'class': 'distance'}),
                   'load_time': DateTimePickerInput}

    class Media:
        css = {'all': ('assets/js/leaflet/leaflet.css',
                       'assets/js/leaflet-routing-machine-3.2.12/dist/leaflet-routing-machine.css',
                       'forms/order_create.css',)}
        js = ('assets/js/leaflet/leaflet.js',
              'assets/js/leaflet-routing-machine-3.2.12/dist/leaflet-routing-machine.js',
              'forms/order_create.js')


class CargoMoveOrderPointForm(RoutePointForm):
    type = forms.ChoiceField(choices=ROUTE_POINT_TYPE_CHOICES, widget=forms.RadioSelect(attrs={'class': 'point-type'}))

    class Meta:
        fields = ['type', 'address', 'latitude', 'longitude', 'ordering']
        widgets = {'latitude': forms.HiddenInput(attrs={'class': 'latitude'}),
                   'longitude': forms.HiddenInput(attrs={'class': 'longitude'}),
                   'address': forms.TextInput(attrs={'class': 'address'}),
                   'ordering': forms.HiddenInput(attrs={'class': 'ordering'})}
        model = RoutePoint


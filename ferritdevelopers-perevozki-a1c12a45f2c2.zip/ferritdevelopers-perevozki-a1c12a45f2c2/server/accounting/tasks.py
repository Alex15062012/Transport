from .models import Transaction, COMPLETE, REJECTED
import requests
import hashlib
import json
from django.conf import settings
from server.celery import app as celery_app


@celery_app.task()
def check_transactions():
    for t in Transaction.objects.filter(is_checked=False, ps_details__isnull=False):
        url = 'https://securepay.tinkoff.ru/v2/GetState'
        try:
            ps_details = json.loads(t.ps_details)
        except json.JSONDecodeError:
            t.is_checked = True
            t.status = REJECTED
            t.save()
            continue
        if 'PaymentId' not in ps_details:
            t.is_checked = True
            t.status = REJECTED
            t.save()
            continue
        data = {
            'Password': settings.BANK_TERMINAL_PASSWORD,
            "PaymentId": str(ps_details['PaymentId']),
            "TerminalKey": settings.BANK_TERMINAL_ID,
        }
        s = ''
        for x in data:
            s += data[x]
        data['Token'] = hashlib.sha256(s.encode('utf-8')).hexdigest()
        resp = requests.post(url, json=data)
        print(resp.status_code, resp.text)







import json
from datetime import timedelta
from django.db import models, connection
from django.contrib.gis.geos import Point, GEOSGeometry
from geopy.distance import distance
from django.contrib.gis.db import models as gis_models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from mptt.models import MPTTModel
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth import get_user_model
from django.conf import settings
from django.contrib.postgres.fields import JSONField, ArrayField
import requests
import os
import uuid
from django.utils.timezone import now
from PIL import Image
from geopy.distance import distance
from django.contrib.gis.db.models.functions import Distance
from django_messages.models import Message
from django.template.loader import render_to_string
from accounts.models import User
from django.utils.html import mark_safe


class FederalDistrict(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class SMSQueue(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone_invalid = models.BooleanField(default=False)
    text = models.CharField(max_length=512)
    created_at = models.DateTimeField()
    sent_at = models.DateTimeField(null=True)


class Settlement(models.Model):
    kod = models.CharField(max_length=14)
    kod2 = models.CharField(max_length=11)
    subkod1 = models.CharField(max_length=2)
    subkod2 = models.CharField(max_length=3)
    subkod3 = models.CharField(max_length=3)
    subkod4 = models.CharField(max_length=3, blank=True, null=True)
    p1 = models.CharField(max_length=1)
    p2 = models.CharField(max_length=1)
    kch = models.CharField(max_length=1)
    name = models.CharField(max_length=500)
    name2 = models.CharField(max_length=500, blank=True, null=True)
    notes = models.CharField(max_length=500, blank=True, null=True)
    federal_district = models.ForeignKey(FederalDistrict, on_delete=models.CASCADE)
    region = models.ForeignKey('Region', on_delete=models.CASCADE)
    settlement_type = models.ForeignKey('SettlementType', on_delete=models.CASCADE, null=True, blank=True)


class Region(models.Model):
    oktmo_id = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    federal_district = models.ForeignKey(FederalDistrict, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class SettlementType(models.Model):
    shortname = models.CharField(max_length=50)
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class VehicleCategory(MPTTModel):
    name = models.CharField(max_length=255)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.name


SEARCH_MODE_CHOICES = (
        ('range', _('Range'),),
        ('min', _('Minimum'),),
        ('max', _('Maximum'),),
        ('eq', _('Exact'),),
                      )
FORM_FIELD_CHOICES = (
        ('select', _('Select'),),
        ('text', _('Text'),),
        ('radio', _('Radio'),),
    )

ACCEPT_OFFER_CHOICES = (
    (None, _('None'),),
    ('allow_less', _('Allow less'),),
    ('allow_more', _('Allow more'),),
    ('Exact', _('Exact'),),
)


class VehicleCategoryAttribute(models.Model):
    name = models.CharField(max_length=255)
    category = models.ForeignKey(VehicleCategory, on_delete=models.CASCADE, related_name='attributes')
    position = models.PositiveSmallIntegerField(default=0)
    search_field_type = models.CharField(max_length=255, null=True, choices=FORM_FIELD_CHOICES)
    search_mode = models.CharField(max_length=255, null=True, choices=SEARCH_MODE_CHOICES)
    accept_offer_mode = models.CharField(blank=True, null=True, max_length=31, choices=ACCEPT_OFFER_CHOICES)

    class Meta:
        ordering = ['category', 'position']

    def __str__(self):
        return self.name


class VehicleCategoryAttributeValue(models.Model):
    attribute = models.ForeignKey(VehicleCategoryAttribute, on_delete=models.CASCADE, related_name='values')
    label = models.CharField(max_length=255, blank=True, null=True)
    value = models.CharField(max_length=255)
    min_value = models.FloatField(blank=True, null=True)
    max_value = models.FloatField(blank=True, null=True)

    position = models.PositiveSmallIntegerField(default=0)

    def __str__(self):
        return self.label

    class Meta:
        ordering = ['attribute', 'position']


def get_vehicle_photo_upload_path(instance, filename):
    path = os.path.join(
        'vehicles', "%s" % instance.uuid, filename)
    disk_path = os.path.join(settings.MEDIA_ROOT, path)
    if not os.path.isdir(disk_path):
        os.makedirs(disk_path)
    return path


# noinspection DuplicatedCode
class VehiclePhoto(models.Model):
    image = models.ImageField(null=True, upload_to=get_vehicle_photo_upload_path, blank=True)
    image_cropping = ArrayField(models.IntegerField(), size=4, null=True, blank=True)
    vehicle = models.OneToOneField('Vehicle', related_name='image', on_delete=models.CASCADE, null=True, blank=True)
    uuid = models.UUIDField(default=uuid.uuid4)

    def url(self):
        try:
            return self.image.url
        except Exception as e:
            print(e)

    def cropped_image(self, refresh=False):
        dn, fn = os.path.split(self.image.path)
        cropped_dn = os.path.join(dn, 'cropped')
        cropped_fn = os.path.join(cropped_dn, fn)
        if os.path.isfile(cropped_fn) and not refresh:
            return cropped_fn.replace(str(settings.MEDIA_ROOT), settings.MEDIA_URL)
        im = Image.open(self.image.path)
        box = tuple(self.image_cropping)
        print(box)
        cropped_im = im.crop(box)
        dn = os.path.dirname(cropped_fn)
        if not os.path.isdir(dn):
            os.makedirs(dn)
        cropped_im.save(cropped_fn)
        return cropped_fn.replace(str(settings.MEDIA_ROOT), settings.MEDIA_URL.rstrip('/'))

    def image_size(self):
        try:
            im = Image.open(self.image.path)
            return list(im.size)
        except:
            return


class Vehicle(models.Model):
    category = models.ForeignKey('ServiceType', on_delete=models.CASCADE, blank=True, null=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    uuid = models.UUIDField(default=uuid.uuid4)
    name = models.CharField(max_length=255, null=True, blank=True, verbose_name='Название')
    photo = models.ImageField(max_length=255, upload_to=get_vehicle_photo_upload_path, null=True, blank=True)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True)
    object_id = models.PositiveIntegerField(null=True)
    content_object = GenericForeignKey('content_type', 'object_id')

    def is_free(self):

        return True

    def list_template_name(self):
        s = self.content_type.name
        return 'app/partials/vehicle_list/%s.html' % (self.content_type.name,)


class CheckPoint(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True, verbose_name=_('Название'),
                            help_text=_("Заполните это поле, если часто используете эту точку, чтобы в дальнейшем "
                                        "использовать ее как шаблон, и поставьте отметку ниже"))
    is_template = models.BooleanField(default=False, verbose_name='Использовать как шаблон')
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
    address = models.TextField(blank=True, null=True)
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)
    categories = models.ManyToManyField(VehicleCategory)
    params = models.ManyToManyField(VehicleCategoryAttributeValue)
    created_at = models.DateTimeField(auto_now=True)
    valid_until = models.DateTimeField(blank=True, null=True, verbose_name=_('Действительна до'))


class CheckPointTemplate(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE)

    address = models.TextField(blank=True, null=True)
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)

    def __str__(self):
        return '%s' % (self.address,)


DRAFT = 0
COMPLETE = -1
CANCELLED = -2
ACTIVE = 1

ORDER_PARTIAL_CHOICES = (
    (DRAFT, 'Черновик',),
    (ACTIVE, "Активный"),
)

ORDER_STATUS_CHOICES = ORDER_PARTIAL_CHOICES + (
    (CANCELLED, "Отменен"),
    (COMPLETE, "Выпонен"),
                        )


class JobOrder(models.Model):
    client = models.ForeignKey(User, on_delete=models.CASCADE, null=True, related_name='client_orders')
    executor = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='executor_orders')
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, null=True, related_name='vehicle_orders')
    category = models.ForeignKey('ServiceType', on_delete=models.SET_NULL, null=True)
    uuid = models.UUIDField(default=uuid.uuid4)
    content_type = models.ForeignKey(ContentType, null=True, on_delete=models.SET_NULL)
    date = models.DateTimeField(default=now)
    start_date = models.DateTimeField(null=True)
    valid_duration = models.DurationField(null=True, blank=True,
                                          verbose_name='Срок действия заказа')
    object_id = models.PositiveIntegerField(null=True)
    content_object = GenericForeignKey('content_type', 'object_id')
    notify = models.BooleanField(default=False, verbose_name='Оповещение исполнителей')
    num_messages = models.PositiveSmallIntegerField(default=getattr(settings, 'NOTIFICATIONS_PER_ORDER_DEFAULT', 10))
    notification_cost = models.DecimalField(
        decimal_places=2, max_digits=6,
        default=getattr(settings, 'JOB_ORDER_NOTIFICATION_COST', 50)
    )
    note = models.TextField(blank=True, null=True, verbose_name='Пояснение')
    is_moderated = models.BooleanField(default=False, verbose_name='Проверен')
    is_active = models.BooleanField(default=False, verbose_name='Активирован')
    status = models.PositiveIntegerField(choices=ORDER_STATUS_CHOICES, default=DRAFT, verbose_name="Статус заказа",
                                         help_text='При задание статуса "Черновик" заказ можно изменить. '
                                                   'Обработка заказа начинается после задания статуса "Активен"')
    notify_until = models.DateTimeField(null=True, blank=True)

    def get_details_template(self):
        return 'app/order_templates/%s.html' % (self.content_type.model,)


class JobOrderComment(MPTTModel):
    order = models.ForeignKey(JobOrder, on_delete=models.CASCADE, related_name='comments')
    uuid = models.UUIDField(default=uuid.uuid4)
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='author_comments')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recipient_comments')
    text = models.TextField()
    created_at = models.DateTimeField(default=now)
    parent = models.ForeignKey('self', on_delete=models.SET_NULL, null=True)


class JobOrderNotification(models.Model):
    order = models.ForeignKey(JobOrder, on_delete=models.CASCADE, related_name='notifications')
    vehicle = models.ForeignKey('Vehicle', on_delete=models.CASCADE, null=True)
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recipient_notifications')
    created_at = models.DateTimeField(auto_created=True)
    sent_at = models.DateTimeField(blank=True, null=True)
    valid_until = models.DateTimeField(null=True)
    message = models.OneToOneField(Message, null=True, on_delete=models.CASCADE)

    def create_message(self):
        if self.message is not None:
            return self.message
        ctx = {
            'content_object': self.order.content_object,
            'order': self.order,
            'recipient': self.recipient,
            'valid_until': self.valid_until,
            'vehicle': self.vehicle,
        }
        body_tpl = 'order_notifications/%s_body.html' % (self.order.content_type.model,)
        subject_tpl = 'order_notifications/%s_subject.html' % (self.order.content_type.model,)
        body = render_to_string(body_tpl, ctx)
        subject = render_to_string(subject_tpl, ctx)
        message = Message.objects.create(
            subject=subject, body=body, sender_id=1, recipient=self.recipient,
            sent_at=self.created_at
        )
        self.message = message
        self.save()
        return self.message


class ExecutorRating(models.Model):
    order = models.OneToOneField(JobOrder, on_delete=models.CASCADE)
    executor = models.ForeignKey(User, on_delete=models.CASCADE)
    rate = models.PositiveSmallIntegerField()


class ClientRating(models.Model):
    order = models.OneToOneField(JobOrder, on_delete=models.CASCADE)
    executor = models.ForeignKey(User, on_delete=models.CASCADE)
    rate = models.PositiveSmallIntegerField()


class JobOrderLocation(models.Model):
    address = models.TextField(blank=True, null=True)
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)


class QueuedSMS(models.Model):
    recipients = models.ManyToManyField('accounts.User')
    text = models.TextField()
    process = models.BooleanField(default=False)
    sent_at = models.DateTimeField(blank=True, null=True)
    queued_at = models.DateTimeField(auto_now_add=True)


class LoadingType(models.Model):
    short_name = models.CharField(max_length=64)
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Тип загрузки (перевозки грузов)'
        verbose_name_plural = 'Типы загрузки (перевозки грузов)'


class UnLoadingType(models.Model):
    short_name = models.CharField(max_length=64)
    name = models.CharField(max_length=255)


class TruckTypeGroup(models.Model):
    name = models.CharField(max_length=255)
    position = models.PositiveSmallIntegerField(default=0)


class TruckType(MPTTModel):
    DDL = 1
    RSB = 2
    EL_CHOICES = (
        (DDL, 'Drop down',),
        (RSB, 'Radio select',)
                  )
    groups = models.ManyToManyField(TruckTypeGroup, null=True, blank=True)
    name = models.CharField(max_length=255)
    parent = models.ForeignKey('self', blank=True, null=True, on_delete=models.SET_NULL)
    position = models.PositiveSmallIntegerField(default=0)
    element = models.PositiveSmallIntegerField(choices=EL_CHOICES, default=DDL)
    service_type = models.ForeignKey('ServiceType', related_name='truck_types', null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Тип техники'
        verbose_name_plural = 'Типы техники'


class CargoType(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Тип грузов (перевозки грузов)'
        verbose_name_plural = 'Типы грузов (перевозки грузов)'


class Truck(models.Model):
    type = models.ForeignKey(TruckType, related_name='trucks', on_delete=models.SET_NULL, null=True,
                             verbose_name='Тип кузова')
    type2 = models.ForeignKey(TruckType, related_name='rsb_trucks', on_delete=models.SET_NULL, null=True,
                              )
    loading_types = models.ManyToManyField(LoadingType, blank=True, verbose_name='Тип загрузки')
    load_capacity = models.FloatField(null=True, verbose_name='Грузоподъемность, т')
    load_volume = models.FloatField(null=True, verbose_name='Объем, куб. м.')
    width = models.FloatField(null=True, blank=True, verbose_name='Ширина кузова, м.')
    height = models.FloatField(null=True, blank=True, verbose_name='Высота кузова, м.')
    length = models.FloatField(null=True, blank=True, verbose_name='Длина кузова, м.')
    trailer_width = models.FloatField(null=True, blank=True, verbose_name='Ширина прицепа, м.')
    trailer_height = models.FloatField(null=True, blank=True, verbose_name='Высота прицепа, м.')
    trailer_length = models.FloatField(null=True, blank=True,  verbose_name='Длина прицепа, м.')
    vehicle = models.OneToOneField(Vehicle, on_delete=models.SET_NULL, null=True)


class PackType(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Тип упаковки (перевозки грузов)'
        verbose_name_plural = 'Типы упаковки (перевозки грузов)'


class ServiceType(MPTTModel):
    name = models.CharField(max_length=255)
    parent = models.ForeignKey('self', null=True, on_delete=models.SET_NULL)
    vehicle_form_class = models.CharField(max_length=255, blank=True, null=True)
    vehicle_model = models.CharField(max_length=255, blank=True, null=True)
    order_form_class = models.CharField(max_length=255, blank=True, null=True)
    order_subform_class = models.CharField(max_length=255, blank=True, null=True)
    checkpoint_form_class = models.CharField(max_length=255, blank=True, null=True)
    checkpoint_subform_class = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name


LOAD = 1
UNLOAD = 2
STOP = 3

ROUTE_POINT_TYPE_CHOICES = (
    (LOAD, _('Загрузка'),),
    (UNLOAD, _('Разгрузка'),),
    (STOP, _('Остановка'),),
)


class RoutePoint(models.Model):
    type = models.PositiveSmallIntegerField(null=True, blank=True, choices=ROUTE_POINT_TYPE_CHOICES,
                                            verbose_name='Тип точки')
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, null=True)
    state = models.ForeignKey('VehicleState', blank=True, null=True, on_delete=models.CASCADE, related_name='points')
    order = models.ForeignKey('CargoMoveOrder', blank=True, null=True, on_delete=models.CASCADE,
                              related_name='points')

    address = models.CharField(blank=True, null=True, max_length=512, verbose_name='Адрес',
                               help_text='Укажите адрес, либо выберите точку на карте. '
                                         'При вводе адреса выбирайте вариант из предложенных подсказок')
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)
    starts_at = models.DateTimeField(null=True, blank=True)
    ends_at = models.DateTimeField(null=True, blank=True)
    ordering = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['ordering', 'id']


class VehicleLocation(models.Model):
    state = models.ForeignKey('VehicleState', on_delete=models.CASCADE, null=True, related_name='locations')
    location = gis_models.PointField()
    starts_at = models.DateTimeField(null=True)
    ends_at = models.DateTimeField(null=True)


class VehicleState(models.Model):
    is_static = models.BooleanField(default=False, verbose_name='Техника стоит')
    upload = models.BooleanField(default=False, verbose_name='Догрузка')
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name='states')
    load_radius = models.FloatField(null=True, verbose_name='Радиус загрузки, км')
    unload_radius = models.FloatField(null=True, verbose_name='Радиус разгрузки, км')

    starts_at = models.DateTimeField(null=True, verbose_name='Время начала')
    ends_at = models.DateTimeField(null=True, verbose_name='Время окончания')
    distance = models.FloatField(null=True, blank=True)
    distances = ArrayField(base_field=models.FloatField(), null=True)
    route = gis_models.MultiPointField(null=True, blank=True, geography=True)

    def make_distances(self):
        res = []
        for i in range(len(self.route.coords)-1):
            res.append(distance(self.route.coords[i], self.route.coords[i+1]).meters)
        self.distances = res
        self.save()

    def get_position(self, ts=None, debug=False):
        if self.is_static:
            return self.points.first().latitude, self.points.first().longitude
        if ts is None:
            ts = now()
        route_duration = (self.ends_at - self.starts_at).total_seconds()
        move_duration = (ts - self.starts_at).total_seconds()
        avg_speed = self.distance / route_duration  # метры в секунду
        passed_distance = avg_speed * move_duration
        total = 0
        n = 0
        for i in range(len(self.distances)):
            total += self.distances[i]
            n += 1
            if total > passed_distance:
                break
        n -= 1
        res = self.route.coords[i]
        if not debug:
            return res
        r = requests.get('https://nominatim.openstreetmap.org/reverse', params={'lat': res[0], 'lon': res[1], 'format': 'json'})
        print(ts, r.json()['display_name'], res)
        return res

    def create_distances(self):
        if self.route is None:
            return
        coords = list(self.route.coords)
        res = []
        for i in range(len(coords)-1):
            item = distance(coords[i], coords[i+1]).meters
            res.append(item)
        self.distances = res
        self.save()

    def create_locations(self):
        VehicleLocation.objects.filter(state=self).delete()
        if self.points.count() == 0:
            return
        if self.points.count() == 1 or self.route is None:
            p = self.points.first()
            VehicleLocation.objects.create(
                starts_at=self.starts_at, state=self, ends_at=self.ends_at,
                location=GEOSGeometry('POINT(%s %s)' % (p.latitude, p.longitude,), srid=4326))
            return

        ts = self.starts_at
        _data = []
        cumulative_distances = []
        coords = list(self.route.coords)
        _sum = 0
        for x in self.distances:
            _sum += x
            cumulative_distances.append(_sum)
        route_duration = (self.ends_at - self.starts_at).total_seconds()
        avg_speed = self.distance / route_duration  # метры в секунду
        while ts < self.ends_at:
            move_duration = (ts - self.starts_at).total_seconds()
            passed_distance = avg_speed * move_duration
            min_dst = next(_ for _ in cumulative_distances if _ > passed_distance)
            idx = cumulative_distances.index(min_dst)
            pos = coords[idx]
            pnt = 'POINT(%s %s)' % pos
            _data.append([
                self.id,
                pnt,
                ts,
                ts+timedelta(seconds=300)
            ])
            ts += timedelta(seconds=300)
        sql = 'INSERT INTO app_vehiclelocation (state_id, location, starts_at, ends_at) VALUES {}'
        fmt = ', '.join(['(%s, ST_GeomFromText(%s, 4326), %s, %s)'] * len(_data))
        sql = sql.format(fmt)
        values = []
        for _ in _data:
            values += _
        if len(values) > 0:
            cur = connection.cursor()
            print(cur.mogrify(sql, values))
            cur.execute(sql, values)
            cur.close()

    # noinspection DuplicatedCode
    def post_save(self):
        ids = set()
        if VehicleState.objects.filter(vehicle=self.vehicle, ends_at__gt=self.starts_at).exclude(id=self.id).exists():
            for s in VehicleState.objects.filter(vehicle=self.vehicle, ends_at__gt=self.starts_at).exclude(id=self.id):
                s.ends_at = self.starts_at
                s.save()
                ids.add(s.id)
        if VehicleState.objects.filter(vehicle=self.vehicle, starts_at__lt=self.ends_at).exclude(id=self.id).exists():
            for s in VehicleState.objects.filter(vehicle=self.vehicle, starts_at__lt=self.ends_at).exclude(id=self.id):
                s.starts_at = self.ends_at
                s.save()
                ids.add(s.id)
        # ids.add(self.id)
        ids = list(ids)
        for s in VehicleState.objects.filter(id__in=ids):
            s.create_locations()
        self.create_locations()

    def save(self, force_insert=False, force_update=False, using=None,
             update_fields=None):
        super().save(force_insert=force_insert, force_update=force_update, using=using, update_fields=update_fields)


class OrderPaymentVariant(models.Model):
    name = models.CharField(max_length=63)

    def __str__(self):
        return self.name


class CargoMoveOrder(models.Model):
    valid_for_job_order = True
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    truck_types = models.ManyToManyField(TruckType, verbose_name="Типы техники")
    load_time = models.DateTimeField(verbose_name='Дата загрузки')
    loading_types = models.ManyToManyField(LoadingType,  blank=True,
                                           related_name='order_loading_types',
                                           verbose_name='Загрузка')
    unloading_types = models.ManyToManyField(LoadingType, blank=True, related_name='order_unloading_types',
                                             verbose_name="Разгрузка")
    weight = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Вес, тн')
    volume = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Объем, куб. м.")
    cargo_type = models.ForeignKey(CargoType, blank=True, null=True, on_delete=models.SET_NULL,
                                   verbose_name='Тип груза')
    cargo_type_text = models.CharField(max_length=255, blank=True, null=True, verbose_name="Укажите, "
                                                                                           "если нет в списке")
    start_point = models.ForeignKey(RoutePoint, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='order_start_points')
    end_point = models.ForeignKey(RoutePoint, on_delete=models.SET_NULL, null=True, blank=True,
                                  related_name='order_end_points')
    price_cache = models.PositiveIntegerField(verbose_name="Наличными", null=True, blank=True)
    price_card = models.PositiveIntegerField(verbose_name="На карту", null=True, blank=True)
    price_bank = models.PositiveIntegerField(verbose_name="Безнал", null=True, blank=True)
    price_uom = models.ForeignKey('PriceUnit', null=True, on_delete=models.SET_NULL, verbose_name='Еденица измерения')
    distance = models.FloatField(null=True)
    job_order = models.OneToOneField(JobOrder, null=True, on_delete=models.SET_NULL,
                                     related_name='cargo_order')

    def distance_km(self):
        try:
            return self.distance/1000
        except ValueError:
            return 0

    def points_json(self):
        data = []
        for p in self.points.all():
            item = {
                'type': p.get_type_display(),
                'address': p.address,
                'coordinates': [p.latitude, p.longitude]
            }
            data.append(item)
        return mark_safe(json.dumps(data, ensure_ascii=False))

    def get_executors_qs(self, ts=None):
        if ts is None:
            ts = now()
        ref_location = Point(self.start_point.latitude, self.start_point.longitude, srid=4326)
        ct = ContentType.objects.get_for_model(Truck)
        qs = Vehicle.objects.filter(
            states__locations__starts_at__gte=ts, states__locations__ends_at__lt=ts
        ).annotate(distance=Distance('states__locations__location', ref_location))
        qs = VehicleLocation.objects.filter(
            state__vehicle__content_type=ct, starts_at__gte=ts, ends_at__lt=ts
        ).annotate(
            distance=Distance('location', ref_location)
        ).order_by('-distance').values('state__vehicle', 'distance').distinct()
        return qs

    class Meta:
        verbose_name = 'Перевозка грузов'
        verbose_name_plural = 'Перевозки грузов'


class PriceUnit(models.Model):
    name = models.CharField(max_length=63)
    name_en = models.CharField(max_length=63)
    abbr = models.CharField(max_length=15, null=True, blank=True)
    full_name = models.CharField(max_length=255, null=True)
    service_types = models.ManyToManyField(ServiceType, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Тип упаковки (перевозки грузов)'
        verbose_name_plural = 'Типы упаковки (перевозки грузов)'





from django.db.models.aggregates import Aggregate as SQLAggregate
from django.db.models import Aggregate

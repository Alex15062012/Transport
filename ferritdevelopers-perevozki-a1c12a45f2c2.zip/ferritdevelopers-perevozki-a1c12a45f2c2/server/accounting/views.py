import os
from django.conf import settings
from django.views.generic import ListView, CreateView
from .forms import TransactionCreateForm
from .models import Transaction, PENDING, COMPLETE, REJECTED, MODERATING, PROCESSING
from django.urls import reverse
from django.http.response import HttpResponse


class RefillView(CreateView):
    template_name = 'accounting/refill.html'
    form_class = TransactionCreateForm

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def get_success_url(self):
        url = self.object.init_payment()
        if url is not None:
            return url
        return reverse('transactions')

    # def post(self, request, *args, **kwargs):
    #     res = super(RefillView, self).post(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        return ctx


class TransactionsListView(ListView):
    template_name = 'accounting/transactions_list.html'
    context_object_name = 'transactions'

    def get_queryset(self):
        return Transaction.objects.filter(user=self.request.user)


def notify(request):
    print('POST', request.POST)
    print('GET', request.GET)
    order_id = request.POST['OrderId']

    fp = open(os.path.join(settings.BASE_DIR, '%s.txt' % (order_id,)), 'w')
    fp.write(request.POST.urlencode())
    fp.close()
    order = Transaction.objects.get(id=order_id)
    if request.POST['Success']:
        order.status = COMPLETE
    else:
        order.status = REJECTED
    order.save()

    return HttpResponse(b'')

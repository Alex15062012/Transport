from django.contrib import admin
from .models import FederalDistrict, Region, Settlement, SettlementType, VehicleCategory, \
    VehicleCategoryAttribute, VehicleCategoryAttributeValue, Vehicle, CargoType, LoadingType, ServiceType, TruckType,\
    PackType, Truck, OrderPaymentVariant, SMSQueue, PriceUnit, JobOrder, VehicleState
from .admin_forms import JobOrderAdminForm
from mptt.admin import DraggableMPTTAdmin
from nested_inline.admin import NestedStackedInline, NestedModelAdmin


@admin.register(SMSQueue)
class SMSQueueAdmin(admin.ModelAdmin):
    list_display = ['phone', 'text', 'created_at', 'sent_at']

    def phone(self, obj):
        return obj.user.phone


@admin.register(FederalDistrict)
class FederalDistrictAdmin(admin.ModelAdmin):
    list_display = ['name', 'id']


@admin.register(SettlementType)
class SettlementTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'id']


@admin.register(Region)
class RegionAdmin(admin.ModelAdmin):
    list_display = ['name', 'federal_district', 'id']


@admin.register(Settlement)
class SettlementAdmin(admin.ModelAdmin):
    list_display = ['name', 'region']
    list_filter = ['region']


class VehicleCategoryAttributeValueInline(NestedStackedInline):
    model = VehicleCategoryAttributeValue
    sortable_field_name = "position"


class VehicleCategoryAttributeInline(NestedStackedInline):
    model = VehicleCategoryAttribute
    sortable_field_name = "position"
    inlines = [VehicleCategoryAttributeValueInline]


@admin.register(VehicleCategoryAttribute)
class VehicleCategoryAttributeAdmin(admin.ModelAdmin):
    pass



@admin.register(VehicleCategory)
class VehicleCategoryAdmin(NestedModelAdmin, DraggableMPTTAdmin):
    inlines = [VehicleCategoryAttributeInline]


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    pass


@admin.register(CargoType)
class CargoTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'id']


@admin.register(LoadingType)
class LoadingTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'id']


@admin.register(PackType)
class PackTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'id']


@admin.register(ServiceType)
class ServiceTypeAdmin(DraggableMPTTAdmin):
    list_display = ['indented_title', 'id']


@admin.register(TruckType)
class TruckTypeAdmin(DraggableMPTTAdmin):
    list_display = ['indented_title', 'service_type', 'id']


@admin.register(Truck)
class TruckAdmin(admin.ModelAdmin):
    list_display = ['id', ]


@admin.register(OrderPaymentVariant)
class OrderPaymentVariantAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(PriceUnit)
class PriceUnitAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(JobOrder)
class JobOrderAdmin(admin.ModelAdmin):
    list_display = ['client', 'executor', 'date']
    form = JobOrderAdminForm


@admin.register(VehicleState)
class VehicleStateAdmin(admin.ModelAdmin):
    pass
